package com.scb.otp.mongo.processor;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.scb.core.processors.SCBAbstractServiceProcessor;
import com.scb.core.validation.SCBValidationInfoResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.otp.mongo.collection.TestCollection;


public class SCBOtpMongoUpdateProcessor extends SCBAbstractServiceProcessor{

	@Autowired
	@Qualifier(value="mongoOperations")
	MongoOperations mongoOperation;


	@Override
	public void processRequest(SCBCommObj req, SCBCommObj res) throws Exception {

		String searchId = req.getBody().getSection("MongoUpdate").getStringValue("id");
		String newValue = req.getBody().getSection("MongoUpdate").getStringValue("password");
		Query query = new Query(Criteria.where("id").is(searchId));
		mongoOperation.updateFirst(query,
				Update.update("password", newValue),TestCollection.class);
		SCBFooter footer = new SCBFooter();
		List<SCBValidationInfoResult> list = new ArrayList<SCBValidationInfoResult>();
		SCBValidationInfoResult result = new SCBValidationInfoResult();
		result.setValidationCode("S001");
		result.setValidationValue("Updated successfuly");
		list.add(result);
		footer.setInfos(list);
		res.setFooterInfoList(list);		

	}

}
