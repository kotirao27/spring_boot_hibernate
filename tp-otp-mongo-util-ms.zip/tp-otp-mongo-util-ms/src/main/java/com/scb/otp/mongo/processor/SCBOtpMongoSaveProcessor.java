package com.scb.otp.mongo.processor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoOperations;

import com.scb.core.processors.SCBAbstractServiceProcessor;
import com.scb.ms.communication.SCBCommObj;
import com.scb.otp.mongo.collection.TestCollection;

public class SCBOtpMongoSaveProcessor extends SCBAbstractServiceProcessor{

	
	@Autowired
	@Qualifier(value="mongoOperations")
	MongoOperations mongoOperation;
	
	
	@Override
	public void processRequest(SCBCommObj req, SCBCommObj res) throws Exception {
		// TODO Auto-generated method stub
		TestCollection test = new TestCollection();
		test.setId("1");
		test.setUsername("test");
		test.setPassword("testP");
		
		mongoOperation.save(test);
	}

}
