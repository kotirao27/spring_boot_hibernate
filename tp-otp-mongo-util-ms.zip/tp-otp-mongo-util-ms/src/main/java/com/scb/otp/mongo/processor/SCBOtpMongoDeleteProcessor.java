package com.scb.otp.mongo.processor;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.scb.core.processors.SCBAbstractServiceProcessor;
import com.scb.core.validation.SCBValidationInfoResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.otp.mongo.collection.TestCollection;


public class SCBOtpMongoDeleteProcessor extends SCBAbstractServiceProcessor{

	@Autowired
	@Qualifier(value="mongoOperations")
	MongoOperations mongoOperation;


	@Override
	public void processRequest(SCBCommObj req, SCBCommObj res) throws Exception {

		String searchId = req.getBody().getSection("MongoDelete").getStringValue("id");
		Query query = new Query(Criteria.where("id").is(searchId));
		mongoOperation.remove(query, TestCollection.class);
		SCBFooter footer = new SCBFooter();
		List<SCBValidationInfoResult> list = new ArrayList<SCBValidationInfoResult>();
		SCBValidationInfoResult result = new SCBValidationInfoResult();
		result.setValidationCode("S001");
		result.setValidationValue("Deleted successfuly");
		list.add(result);
		footer.setInfos(list);
		res.setFooterInfoList(list);
	}

}
