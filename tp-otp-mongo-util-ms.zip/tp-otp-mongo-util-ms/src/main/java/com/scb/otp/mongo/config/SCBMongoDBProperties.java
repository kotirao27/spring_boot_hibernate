/*package com.scb.otp.mongo.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;


@Configuration
@ConfigurationProperties
class SCBMongoDBProperties {
	@Value("${mongodb.db}")
	private String database;

	@Value("${mongodb.username}")
	private String dbUserName;

	@Value("${mongodb.password}")
	private String password;

	@Value("${mongodb.ip}")
	private String ip;

	@Value("${mongodb.port}")
	private String port;

	public String getDatabase() {
		return database;
	}

	public void setDatabase(String database) {
		this.database = database;
	}

	public String getDbUserName() {
		return dbUserName;
	}

	public void setDbUserName(String dbUserName) {
		this.dbUserName = dbUserName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}
}
*/