package com.scb.otp.mongo.processor;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.scb.core.processors.SCBAbstractServiceProcessor;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBSection;
import com.scb.otp.mongo.collection.TestCollection;


public class SCBOtpMongoReadProcessor extends SCBAbstractServiceProcessor{

	@Autowired
	@Qualifier(value="mongoOperations")
	MongoOperations mongoOperation;


	@Override
	public void processRequest(SCBCommObj req, SCBCommObj res) throws Exception {

		String searchId = req.getBody().getSection("MongoRetreive").getStringValue("id");
		Query searchUserQuery = new Query(Criteria.where("id").is(searchId));		
		TestCollection col = mongoOperation.findOne(searchUserQuery, TestCollection.class);
		SCBSection sec = new SCBSection();
		Map<String,String> stringData = new HashMap<String,String>();
		stringData.put("id", col.getId());
		stringData.put("username", col.getUsername());
		stringData.put("password", col.getPassword());
		sec.setStringData(stringData);
		res.setBodySection("Test", sec);
	}

}
