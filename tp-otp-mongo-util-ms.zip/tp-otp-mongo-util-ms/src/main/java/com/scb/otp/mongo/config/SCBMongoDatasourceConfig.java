package com.scb.otp.mongo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.Mongo;
import com.mongodb.MongoClient;

@Configuration
/*@EnableMongoRepositories(basePackages = "com.scb.ms.alert.dao")*/
public class SCBMongoDatasourceConfig extends AbstractMongoConfiguration {

	//private SCBMongoDBProperties config;


	public String getDatabaseName() {
		return "test-db";
	}

	/*private void load() {
		String password = environment.getProperty(ENCRYPTION_PASSWORD_ENVIRONMENT_VAR_NAME_UNDERSCORE);
		logger.debug(ENCRYPTION_PASSWORD_ENVIRONMENT_VAR_NAME_UNDERSCORE + "=" + password);
		if (password == null || StringUtils.isEmpty(password)) {
			mongoCredential = MongoCredential.createCredential(config.getDbUserName(), config.getDatabase(), config.getPassword().toCharArray());
			return;
		}
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword(password);
		final Properties props = new Properties();
		props.put("password", config.getPassword());
		PropertySource<?> property = new EncryptablePropertiesPropertySource("source", props, encryptor);
		String decryptedPwd = property.getProperty("password").toString();
		mongoCredential = MongoCredential.createCredential(config.getDbUserName(), config.getDatabase(), decryptedPwd.toCharArray());
	}*/

	@Override
	@Bean
	public Mongo mongo() throws Exception {
		return new MongoClient("10.23.210.42");
		/*		if(!StringUtils.isEmpty(config.getDbUserName())){
			load();
			return new MongoClient(new ServerAddress(config.getIp(), Integer.parseInt(config.getPort())), new ArrayList<MongoCredential>() {
				{
					add(mongoCredential);
				}
			});
		} else
			return new MongoClient(config.getIp());*/
	}
	
	@Bean(name="mongoOperations")
    public MongoOperations mongoFactory() throws Exception {
		MongoOperations mongoOps = new MongoTemplate(mongo(), getDatabaseName());
		return mongoOps;
    }
}