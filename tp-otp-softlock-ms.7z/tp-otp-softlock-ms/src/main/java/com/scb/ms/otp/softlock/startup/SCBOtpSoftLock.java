package com.scb.ms.otp.softlock.startup;


import org.jsondoc.spring.boot.starter.EnableJSONDoc;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.integration.IntegrationAutoConfiguration;
import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@EnableEurekaClient
@Configuration
@EnableAutoConfiguration(exclude={JmxAutoConfiguration.class , IntegrationAutoConfiguration.class})
@SpringBootApplication(scanBasePackages = {"com.scb.core","com.scb.ms","com.scb.ms.otp","com.scb.ms.otp.softlock"})
@ComponentScan({"com.scb.core","com.scb.ms","com.scb.ms.otp","com.scb.ms.otp.softlock","com.scb.otp.softlock.util"})
@EntityScan({"com.scb.opt.softlock.util"})
@EnableJSONDoc
public class SCBOtpSoftLock extends SpringBootServletInitializer {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SCBOtpSoftLock.class);

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(SCBOtpSoftLock.class);
	}
	public static void main(String[] args){
		SpringApplication.run(SCBOtpSoftLock.class, args);		
		LOGGER.info("==========SCBOtpSoftLock---Started====================>");
	}

}
