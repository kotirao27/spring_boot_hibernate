package com.scb.ms.otp.softlock.processors;

import org.springframework.beans.factory.annotation.Autowired;
import com.scb.core.processors.SCBAbstractServiceProcessor;
import com.scb.ms.communication.SCBCommObj;
import com.scb.otp.softlock.util.service.SCBOtpSoftLockService;

public class SCBOtpSoftLockRecordProcessor extends SCBAbstractServiceProcessor {

	@Autowired
	private SCBOtpSoftLockService softLockService;

	@SuppressWarnings({ "unchecked" })
	@Override
	public void processRequest(SCBCommObj request, SCBCommObj response) throws Exception {
		
		softLockService.acquireLock(request);
	}
}
