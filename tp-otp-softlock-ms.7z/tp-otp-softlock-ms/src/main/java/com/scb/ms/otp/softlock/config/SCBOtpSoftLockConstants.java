package com.scb.ms.otp.softlock.config;

public interface SCBOtpSoftLockConstants {

	 final String CHECK_LOCK = "CHECK_LOCK";
	final String RELEASE_LOCK = "RELEASE_LOCK";
}
