package com.scb.ms.otp.softlock.processors;

import org.springframework.beans.factory.annotation.Autowired;

import com.scb.core.processors.SCBAbstractServiceProcessor;
import com.scb.ms.communication.SCBCommObj;
import com.scb.otp.softlock.util.service.SCBOtpSoftLockService;

public class SCBOtpReleaseSoftLockProcessor extends SCBAbstractServiceProcessor {
	
	@Autowired
	public SCBOtpSoftLockService softLockService;

	@Override
	public void processRequest(SCBCommObj request, SCBCommObj response) throws Exception {
		// TODO Auto-generated method stub
		softLockService.releaseLock(request);
	}

}
