package com.scb.ms.otp.softlock.resources;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.scb.core.services.SCBComObjService;
import com.scb.core.validation.SCBValidationErrorResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;


@RestController
@RequestMapping("/ms/otp")
public class SCBOtpSoftLockController {

	static final Logger logger = LoggerFactory.getLogger(SCBOtpSoftLockController.class);

	@Autowired
	private SCBComObjService scbComObjService;

	@RequestMapping(value = "/softlock", method = RequestMethod.POST, consumes = { MediaType.APPLICATION_JSON_VALUE,  MediaType.APPLICATION_XML_VALUE},
			produces = { MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody SCBCommObj lockRecord(@RequestBody SCBCommObj comObj) {

		comObj.setFooter(new SCBFooter()); // Removing footer from request.
		SCBCommObj responseObj = new SCBCommObj();
		try{
			responseObj = scbComObjService.processRequest(comObj);
			return responseObj;
		}catch(Exception e){
			logger.error("======Error in soft lock =====>", e);
			SCBValidationErrorResult errors = new SCBValidationErrorResult();
			errors.setValidationCode("Error code");
			errors.setValidationValue("Error Value");
			errors.setParams(new String[]{e.getMessage()});
			responseObj.getFooter().getErrors().add(errors);

			return responseObj;
		}
	}


}
