//package com.scb.ms.otp.softlock.eo;
//
//import java.util.Date;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//
//@Entity
//@Table(name="SCBT_T_SOFT_LOCK")
//public class SCBSoftLockEO {
//
//	@Id
//	@Column(name="LOCK_KEY")
//	public String lockKey;
//	
//	@Column(name="SESSION_ID")
//	public String sessionId;
//	
//	@Column(name="COMPONENT_ID")
//	public String componentId;
//	
//	@Column(name="USER_ID")
//	public String userId;
//	
//	@Column(name="LOCK_TIMESTAMP")
//	public Date lockTimeStamp;
//	
//	@Column(name="BANK_GROUP_CODE")
//	public String bankGroupCode;
//	
//	@Column(name="CTY_CODE")
//	public String ctyCode;
//	
//	public String getLockKey() {
//		return lockKey;
//	}
//
//	public void setLockKey(String lockKey) {
//		this.lockKey = lockKey;
//	}
//
//	public String getSessionId() {
//		return sessionId;
//	}
//
//	public void setSessionId(String sessionId) {
//		this.sessionId = sessionId;
//	}
//
//	public String getComponentId() {
//		return componentId;
//	}
//
//	public void setComponentId(String componentId) {
//		this.componentId = componentId;
//	}
//
//	public String getUserId() {
//		return userId;
//	}
//
//	public void setUserId(String userId) {
//		this.userId = userId;
//	}
//
//	public Date getLockTimeStamp() {
//		return lockTimeStamp;
//	}
//
//	public void setLockTimeStamp(Date lockTimeStamp) {
//		this.lockTimeStamp = lockTimeStamp;
//	}
//
//	public String getBankGroupCode() {
//		return bankGroupCode;
//	}
//
//	public void setBankGroupCode(String bankGroupCode) {
//		this.bankGroupCode = bankGroupCode;
//	}
//
//	public String getCtyCode() {
//		return ctyCode;
//	}
//
//	public void setCtyCode(String ctyCode) {
//		this.ctyCode = ctyCode;
//	}
//
//	public String getTbuCode() {
//		return tbuCode;
//	}
//
//	public void setTbuCode(String tbuCode) {
//		this.tbuCode = tbuCode;
//	}
//
//	public String getHostName() {
//		return hostName;
//	}
//
//	public void setHostName(String hostName) {
//		this.hostName = hostName;
//	}
//
//	@Column(name="TBU_CODE")
//	public String tbuCode;
//	
//	@Column(name="HOST_NAME")
//	public String hostName;
//	
//	
//	
//}
