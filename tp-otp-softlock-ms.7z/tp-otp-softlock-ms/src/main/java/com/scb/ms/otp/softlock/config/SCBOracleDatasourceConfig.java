package com.scb.ms.otp.softlock.config;

import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.SessionFactory;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.spring31.properties.EncryptablePropertiesPropertySource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.env.PropertySource;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;

import com.scb.otp.softlock.util.eo.SCBSoftLockEO;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@ConfigurationProperties(prefix = "params.dataSource")
public class SCBOracleDatasourceConfig extends HikariConfig {
	private static final String ENCRYPTION_PASSWORD_ENVIRONMENT_VAR_NAME_UNDERSCORE = "APP_ENCRYPTION_PASSWORD";
	@Autowired
	private Environment environment;

	@SuppressWarnings("rawtypes")
	private void load() {
		String password = environment.getProperty(ENCRYPTION_PASSWORD_ENVIRONMENT_VAR_NAME_UNDERSCORE);
		if (password == null || StringUtils.isEmpty(password)) {
			return;
		}
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword(password);
		final Properties props = new Properties();
		props.put("username", this.getUsername());
		props.put("password", this.getPassword());
		PropertySource property = new EncryptablePropertiesPropertySource("source", props, encryptor);
		this.setUsername(property.getProperty("username").toString());
		this.setPassword(property.getProperty("password").toString());
	}

    @Bean
    public DataSource dataSource() throws SQLException {
		load();
        return new HikariDataSource(this);
    }
    @Bean(name = "softLockSessionFactory")
	public SessionFactory staSessionFactory() throws SQLException {
		LocalSessionFactoryBuilder builder = new LocalSessionFactoryBuilder(dataSource());
		builder.addAnnotatedClasses(SCBSoftLockEO.class);
		builder.addResource("SCBSoftLockNativeSQL.hbm.xml");
		return builder.buildSessionFactory();
	}
}