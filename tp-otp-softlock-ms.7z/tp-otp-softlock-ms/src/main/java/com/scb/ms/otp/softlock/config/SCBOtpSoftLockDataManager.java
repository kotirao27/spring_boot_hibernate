package com.scb.ms.otp.softlock.config;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.jpa.HibernateEntityManagerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component
@Scope(value="singleton")
public class SCBOtpSoftLockDataManager {
	
	@Autowired
	@Qualifier("softLockSessionFactory")
	private SessionFactory sessionFactory;
	
	
	public Session getSession()  {
		return sessionFactory.getCurrentSession();
	}
	
	@Bean  
	public SessionFactory sessionFactory(HibernateEntityManagerFactory hemf){  
	    return hemf.getSessionFactory();  
	}

}
